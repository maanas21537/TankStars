package com.mygdx.game.Screens;

public class ExplotionType {
    public void render() {
    }
}
