package com.mygdx.game.Screens;

import com.mygdx.game.Sprites.Tank;
import com.mygdx.game.TankStars;

import java.io.*;

public class SaveLoad implements Serializable {
    private float tank1x;
    private float tank2x;
    private float tank1y;

    public float getTank1x() {return tank1x;}
    public void setTank1x(float tank1x) {this.tank1x = tank1x;}
    public float getTank2x() {return tank2x;}
    public void setTank2x(float tank2x) {this.tank2x = tank2x;}
    public float getTank1y() {return tank1y;}
    public void setTank1y(float tank1y) {this.tank1y = tank1y;}
    public float getTank2y() {return tank2y;}
    public void setTank2y(float tank2y) {this.tank2y = tank2y;}
    public float getHealth1() {return health1;}
    public void setHealth1(float health1) {this.health1 = health1;}
    public float getHealth2() {return health2;}
    public void setHealth2(float health2) {this.health2 = health2;}

    private float tank2y;
    private float health1;
    private float health2;
    public void savedata(Tank tank1,Tank tank2, String filename){

        tank1x = tank1.getX();
        tank1y = tank1.getY();
        tank2x = tank2.getX();
        tank2y = tank2.getY();
        health1 = tank1.getHealth();
        health2 = tank2.getHealth();
        try
        {
            //Saving of object in a file
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);

            // Method for serialization of object
            out.writeObject(this);

            out.close();
            file.close();

            System.out.println("Object has been serialized");

        }

        catch(IOException ex)
        {
            System.out.println("IOException is caught");
            System.out.println(ex);
        }
    };
    public SaveLoad loaddata(String filename){
        try
        {
            // Reading the object from a file
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(file);

            // Method for deserialization of object
            SaveLoad s = (SaveLoad)in.readObject();

            in.close();
            file.close();

            return s;
        }

        catch(IOException ex)
        {
//            System.out.println("IOException is caught");
            System.out.println(ex);
        }

        catch(ClassNotFoundException ex)
        {
            System.out.println("ClassNotFoundException is caught");
        }
        return null;
    };
}
