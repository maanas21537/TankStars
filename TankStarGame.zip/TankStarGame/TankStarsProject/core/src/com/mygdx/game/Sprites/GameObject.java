package com.mygdx.game.Sprites;

import com.mygdx.game.Screens.PlayScreen;

import java.awt.*;
import java.awt.image.BufferedImage;

public abstract class GameObject {




    private float y_velocity;
    private StringBuffer fileNames;
    private String folderFilesPath = null;
    private PlayScreen gameMap;
    private float x_velocity;

    public float getX_velocity() {return x_velocity;}
    public void setX_velocity(float x_velocity) {this.x_velocity = x_velocity;}
    public float getY_velocity() {return y_velocity;}
    public void setY_velocity(float y_velocity) {this.y_velocity = y_velocity;}
    public StringBuffer getFileNames() {return fileNames;}
    public void setFileNames(StringBuffer fileNames) {this.fileNames = fileNames;}
    public String getFolderFilesPath() {return folderFilesPath;}
    public void setFolderFilesPath(String folderFilesPath) {this.folderFilesPath = folderFilesPath;}
    public PlayScreen getGameMap() {return gameMap;}
    public void setGameMap(PlayScreen gameMap) {this.gameMap = gameMap;}


    public abstract void render(Graphics2D graphics);

    public abstract void update();}