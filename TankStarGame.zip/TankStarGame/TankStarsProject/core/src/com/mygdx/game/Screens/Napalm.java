package com.mygdx.game.Screens;

import com.mygdx.game.Sprites.Tank;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import static com.badlogic.gdx.Gdx.graphics;

public class Napalm extends Weapon {
    @Override
    public void update() {
        super.update();
    }

    @Override
    public void render(Graphics2D graphics) {
        super.render( graphics );
    }

    public Napalm(PlayScreen gameMap, Tank tank) {
        setWeaponT( WeaponType.NAPALM );
        setDamage( 10 );
        setParentTank( tank );
        setGameMap( gameMap );
        setX_velocity( 0 );
        setY_velocity( 0 );

    }
}
