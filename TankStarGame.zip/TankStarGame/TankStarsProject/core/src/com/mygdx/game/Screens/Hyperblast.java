package com.mygdx.game.Screens;

import com.mygdx.game.Sprites.Tank;

import java.awt.*;

public class Hyperblast extends Weapon {
    @Override
    public void render(Graphics2D graphics) {
        super.render( graphics );
    }

    @Override
    public void update() {
        super.update();
    }

    public Hyperblast(PlayScreen gameMap, Tank tank) {
        setWeaponT(WeaponType.HYPERBLAST );
        setDamage( 5 );
        setParentTank( tank );
    }
}
