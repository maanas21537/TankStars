package com.mygdx.game.Screens;

import com.mygdx.game.Sprites.Tank;

public enum WeaponType {

    /**
     * Declare the types of weapons here
     */
    NAPALM, HYPERBLAST;

    public static String getName(WeaponType type){

        switch(type){
            case NAPALM:		return "Napalm";
            case HYPERBLAST		:		return "Hyperblast";

            default: {
                System.err.println("Weapon not registered in WeaponType.");
                return "Not-Registered-Weapon";
            }
        }

    }


    public static void addWeaponsToTank(PlayScreen gameMap, Tank tank){

        for(int i = 0; i < 3; i++){
            Napalm napalm = new Napalm(gameMap,	tank);
            tank.addWeapon(napalm);

            Hyperblast	hyperblast = new Hyperblast(gameMap, tank);
            tank.addWeapon(hyperblast);
        }

    }

}
