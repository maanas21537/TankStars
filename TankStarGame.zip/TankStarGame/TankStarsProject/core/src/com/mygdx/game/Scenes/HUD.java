package com.mygdx.game.Scenes;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.Screens.MButton;
import com.mygdx.game.Screens.MainMenu;
import com.mygdx.game.Screens.PauseMenu;
import com.mygdx.game.Screens.PlayScreen;
import com.mygdx.game.TankStars;

import static com.mygdx.game.TankStars.V_HEIGHT;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;

public class HUD implements Disposable {


    private long lastUpdate = 0L;
    private HealthBar healthBar1;
    private HealthBar healthBar2;

    public long getLastUpdate() {return lastUpdate;}
    public void setLastUpdate(long lastUpdate) {this.lastUpdate = lastUpdate;}
    public HealthBar getHealthBar1() {return healthBar1;}
    public HealthBar getHealthBar2() {return healthBar2;}
    public void setHealthBar1(HealthBar healthBar) {this.healthBar1 = healthBar;}
    public void setHealthBar2(HealthBar healthBar) {this.healthBar2 = healthBar;}
    // -------------------------------
    private TankStars game;
    private Viewport viewport;
    public Stage stage;


    public HUD(SpriteBatch sb, final TankStars game, final PlayScreen playScreen) {
        this.game = game;
        //        blank = new Texture( "blank.png" );
        viewport = new FitViewport( TankStars.V_WIDTH, TankStars.V_HEIGHT, new OrthographicCamera() );
        stage = new Stage( viewport, sb );
        Gdx.input.setInputProcessor(stage);

//        Table table1 = new Table();
//        table1.setWidth(500);
//        table1.setHeight(600);
//        table1.top().right();
        Table Controltable = new Table();
        Table Optiontable = new Table();
        Table Weapontable = new Table();
        Table Healthtable = new Table();


        Controltable.setFillParent( true );
        Optiontable.setFillParent( true );
        Weapontable.setFillParent( true );
        Healthtable.setFillParent( true );
//        Optiontable.setWidth( stage.getWidth() );
//        Optiontable.setHeight( stage.getHeight() );

        Controltable.bottom().left();
        Optiontable.top().left();
        Weapontable.bottom().right();
        Healthtable.top().left();
//        table.align( Align.center|Align.top );
//        Controltable.setDebug(true);
//        Optiontable.setDebug( true );
//        Weapontable.setDebug( true );
//        Healthtable.setDebug( true );


        Image FireImg1 = new Image(new Texture("firebutton.png"));
//        Image FireImg2 = new Image(new Texture("firebutton.png"));
        Image w1 = new Image(new Texture("w1.png"));
        Image w2 = new Image(new Texture("w2.png"));
        Image w3 = new Image(new Texture("w3.png"));

        Image PauseImg = new Image(new Texture("pause.png"));

        FireImg1.setSize( 150,50 );
        PauseImg.setSize( 100,100 );
        w1.setSize( 150,50 );
        w2.setSize( 150,50 );
        w3.setSize( 150,50 );

        FireImg1.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
//                System.out.println("clicked");

            }});
        w1.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
//                System.out.println("clicked");
            }});
        w2.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
//                System.out.println("clicked");
            }});
        w3.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
//                System.out.println("clicked");
            }});

        PauseImg.addListener( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                  game.setScreen(new PauseMenu(game,playScreen));
//                System.out.println("clicked");
            }});

        //        FireImg2.addListener( new ClickListener() {
//            @Override
//            public void clicked(InputEvent event, float x, float y) {
////                System.out.println("clicked");
//            }});


        healthBar1 = new HealthBar(400, 30);
        healthBar2 = new HealthBar(400, 30);

        Controltable.add(FireImg1).size(FireImg1.getWidth(),FireImg1.getHeight()).pad( 0,40,50,0).space( 0,0,0,0);
        Weapontable.add(w1).size(w1.getWidth(),w1.getHeight()).pad( 0,40,50,0).space( 0,0,0,0);
        Weapontable.add(w2).size(w2.getWidth(),w2.getHeight()).pad( 0,0,50,0).space( 0,0,0,0);
        Weapontable.add(w3).size(w3.getWidth(),w3.getHeight()).pad( 0,0,50,0).space( 0,0,0,0);
        Optiontable.add(PauseImg).size(PauseImg.getWidth(),PauseImg.getHeight()).pad( 0,0,0,0).space( 0,0,0,0);
        Healthtable.add(healthBar1).size(healthBar1.getWidth(),healthBar1.getHeight()).pad( 80,150,0,0).space( 0,0,0,100);
        Healthtable.add(healthBar2).size(healthBar2.getWidth(),healthBar2.getHeight()).pad( 80,0,0,0).space( 0,0,0,0);

//        stage.addActor( healthBar );
        stage.addActor( Healthtable );
        stage.addActor(Controltable);
        stage.addActor(Optiontable);
        stage.addActor( Weapontable );
    }

    @Override
    public void dispose(){
    }
}
