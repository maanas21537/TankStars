package com.mygdx.game.Screens;

import com.mygdx.game.Sprites.Tank;

public class Player {
    //Attributes
    private String name;
    private int playerid;
    private Tank OwnedTank;
    //GetterSetter
    public int getPlayerid() {return playerid;}
    public void setPlayerid(int playerid) {this.playerid = playerid;}
    public Tank getOwnedTank() {return OwnedTank;}
    public void setOwnedTank(Tank ownedTank) {OwnedTank = ownedTank;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
}
