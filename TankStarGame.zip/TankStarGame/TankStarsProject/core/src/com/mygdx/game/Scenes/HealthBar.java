package com.mygdx.game.Scenes;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;

public class HealthBar extends ProgressBar {

    public HealthBar(int width, int height) {
        super( 0f, 1f, 0.01f, false, new ProgressBarStyle() );
        getStyle().background = Cutils.getColoredDrawable( width, height, Color.DARK_GRAY );
        getStyle().knob = Cutils.getColoredDrawable( 0, height, Color.GOLD);
        getStyle().knobBefore = Cutils.getColoredDrawable( width, height, Color.GOLD );

        setWidth( width );
        setHeight( height );

        setAnimateDuration( 0.0f );
        setValue( 1f );

        setAnimateDuration( 0.25f );
    }
}
