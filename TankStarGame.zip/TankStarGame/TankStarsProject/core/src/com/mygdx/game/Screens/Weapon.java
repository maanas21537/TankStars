package com.mygdx.game.Screens;

import com.mygdx.game.Sprites.GameObject;
import com.mygdx.game.Sprites.Tank;

import java.awt.*;
import java.util.ArrayList;

public class Weapon extends GameObject {
    private float damage;
    private Tank parentTank;
    private WeaponType weaponT;
    private ExplotionType explotionType;

    public float getDamage(){return damage;}
    public void setDamage(float damage) {this.damage = damage;}
    public Tank getParentTank() {return parentTank;}
    public void setParentTank(Tank parentTank) {this.parentTank = parentTank;}
    public WeaponType getWeaponT() {return weaponT;}
    public void setWeaponT(WeaponType weaponT) {this.weaponT = weaponT;}
    public void addWeaponToTank(){

    }

    @Override
    public void render(Graphics2D graphics) {

    }

    @Override
    public void update() {

    }
}
