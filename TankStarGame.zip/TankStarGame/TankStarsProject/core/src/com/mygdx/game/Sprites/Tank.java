package com.mygdx.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.mygdx.game.Screens.PlayScreen;
import com.mygdx.game.Screens.Player;
import com.mygdx.game.Screens.Weapon;
import com.mygdx.game.TankStars;

import java.util.ArrayList;

public class Tank extends Sprite {

    private float health;
    private float angle;
    private float power;
    private Player parentPlayer;
    private ArrayList<Weapon> weapons;

    public float getHealth() {return health;}
    public void setHealth(float health) {this.health = health;}
    public float getAngle() {return angle;}
    public void setAngle(float angle) {this.angle = angle;}
    public float getPower() {return power;}
    public void setPower(float power) {this.power = power;}
    public Player getParentPlayer() {return parentPlayer;}
    public void setParentPlayer(Player parentPlayer) {this.parentPlayer = parentPlayer;}


    public World world;
    public Body b2body;
    private TextureRegion TankStill1;
    private TextureRegion TankStill2;
    public Tank(World world,PlayScreen screen,int k){
        super(screen.getAtlas().findRegion("tanksline"));
        this.world = world;
        angle = 60;
        power =50;
        if( k == 1){
        defineTank();
            TankStill1 = new TextureRegion(getTexture(),5,-15,130,100);
//        setBounds( 0,0,16/TankStars.PPM,16/TankStars.PPM);
            setBounds( 10 ,10,120,100);
//        setBounds( 0,0,100,100);
//        setBounds( 0,0,0.16f,0.16f);
//        setBounds( 0,0,0.43f,0.43f);
            setRegion( TankStill1 );}
        if (k == 2) {
            defineTank1();

        TankStill2 = new TextureRegion(getTexture(),5,-15,130,100);
//        setBounds( 0,0,16/TankStars.PPM,16/TankStars.PPM);
        setBounds( 20 ,20,120,100);
//        setBounds( 0,0,100,100);
//        setBounds( 0,0,0.16f,0.16f);
//        setBounds( 0,0,0.43f,0.43f);
        setRegion( TankStill2 ); }
    }

    public void update(float dt){
        setPosition( b2body.getPosition().x - getWidth()/2,b2body.getPosition().y - getHeight()/2);

    }
    public void defineTank(){
        BodyDef bdef = new BodyDef();
        bdef.position.set(800/ TankStars.PPM,200/ TankStars.PPM);
//        bdef.position.set(32,32);
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody( bdef );
        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();
        shape.setRadius(40/ TankStars.PPM);
//        shape.setRadius(6);

        fdef.shape = shape;
        b2body.createFixture(fdef);
        weapons = new ArrayList<Weapon>();
    }
    public void defineTank1(){
        BodyDef bdef = new BodyDef();
        bdef.position.set(1000/ TankStars.PPM,200/ TankStars.PPM);
//        bdef.position.set(32,32);
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody( bdef );
        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();
        shape.setRadius(40/ TankStars.PPM);
//        shape.setRadius(6);

        fdef.shape = shape;
        b2body.createFixture(fdef);
        weapons = new ArrayList<Weapon>();
    }

    public void addWeapon(Weapon weapon){weapons.add(weapon);}
    public void deleteWeapon(Weapon weapon){weapons.remove(weapon);}
    public void fireWeapon(){}
    public void moveLeft(){
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && this.b2body.getLinearVelocity().x >= -2)
            this.b2body.applyLinearImpulse(new Vector2(-50f, 0), this.b2body.getWorldCenter(), true);
    }
    public void moveRight(){
        if (Gdx.input.isKeyPressed( Input.Keys.RIGHT) && this.b2body.getLinearVelocity().x >= -2)
            this.b2body.applyLinearImpulse(new Vector2(-50f, 0), this.b2body.getWorldCenter(), true);
    }

//    public ArrayList<Double> getPosition(){
//        ArrayList<Double> a = new ArrayList<>();
//        a.add( b2body.getPosition().x )
//    }

}
